@echo off
title SPAR Arduino Nano Firmware Updater
echo ===========================================
echo       SPAR Arduino Nano Firmware Updater
echo ===========================================
echo.

:: List available COM ports
echo Available COM Ports:
powershell -Command "[System.IO.Ports.SerialPort]::GetPortNames()"
echo.

:: Prompt for port
set /p COMPORT="Enter the COM port (e.g., COM3): "

echo.
echo Which bootloader does your Arduino Nano have?
echo [1] New Bootloader (Newer Arduino Nano)
echo [2] Old Bootloader (Older or clone Arduino Nano)
set /p BOOT="Type 1 or 2 and press Enter: "

if "%BOOT%"=="1" set BAUD=115200
if "%BOOT%"=="2" set BAUD=57600

echo.
echo Flashing firmware to %COMPORT% at %BAUD% baud...
avrdude.exe -C avrdude.conf -v -p atmega328p -c arduino -P %COMPORT% -b %BAUD% -D -U flash:w:arduino_nano_spar_regular.hex:i

echo.
if %errorlevel% neq 0 (
    echo ======================================================================
    echo ERROR: Upload failed. 
    echo Try running the script again and picking the OTHER bootloader option.
    echo ======================================================================
) else (
    echo =========================================
    echo SUCCESS: SPAR Firmware updated!
    echo =========================================
)

pause
