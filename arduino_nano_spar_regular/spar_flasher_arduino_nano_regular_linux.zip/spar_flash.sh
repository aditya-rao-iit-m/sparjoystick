#!/bin/bash
echo "============================================="
echo "      SPAR Arduino Nano Firmware Updater"
echo "============================================="
echo ""

echo "Available USB Serial Ports:"
ls /dev/ttyUSB* /dev/ttyACM* 2>/dev/null
echo ""

read -p "Enter the port from above (e.g., /dev/ttyUSB0): " COMPORT

echo ""
echo "Which bootloader does your Arduino Nano have?"
echo "[1] New Bootloader (Newer Arduino Nano)"
echo "[2] Old Bootloader (Older or clone Arduino Nano)"
read -p "Type 1 or 2 and press Enter: " BOOT

if [ "$BOOT" = "1" ]; then
    BAUD=115200
elif [ "$BOOT" = "2" ]; then
    BAUD=57600
else
    echo "Invalid choice. Exiting."
    exit 1
fi

echo ""
echo "Flashing firmware to $COMPORT at $BAUD baud..."
./avrdude -C avrdude.conf -v -p atmega328p -c arduino -P $COMPORT -b $BAUD -D -U flash:w:arduino_nano_spar_regular.hex:i

if [ $? -eq 0 ]; then
    echo "========================================="
    echo "SUCCESS: SPAR Firmware updated!"
    echo "========================================="
else
    echo "==================================================================="
    echo "ERROR: Upload failed."
    echo "If it failed, try running again and picking the OTHER bootloader."
    echo "==================================================================="
fi
