@echo off
title SPAR Arduino UNO R3 Firmware Updater
echo ================================================
echo        SPAR Arduino UNO R3 Firmware Updater
echo ================================================
echo.

:: List available COM ports
echo Available COM Ports:
powershell -Command "[System.IO.Ports.SerialPort]::GetPortNames()"
echo.

:: Prompt for port
set /p COMPORT="Enter the COM port (e.g., COM3): "

echo.
echo Flashing firmware to %COMPORT% at 115200 baud...
avrdude.exe -C avrdude.conf -v -p atmega328p -c arduino -P %COMPORT% -b 115200 -D -U flash:w:arduino_uno_spar_regular.hex:i

echo.
if %errorlevel% neq 0 (
    echo ======================================================================
    echo ERROR: Upload failed. 
    echo Make sure the correct COM port is selected, the UNO is plugged in,
    echo and no other programs are currently using the port.
    echo ======================================================================
) else (
    echo =========================================
    echo SUCCESS: SPAR Firmware updated!
    echo =========================================
)

pause
