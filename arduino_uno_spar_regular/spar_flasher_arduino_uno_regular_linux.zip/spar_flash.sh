#!/bin/bash
echo "=============================================="
echo "    SPAR Arduino UNO R3 Firmware Updater"
echo "=============================================="
echo ""

echo "Available USB Serial Ports:"
ls /dev/ttyUSB* /dev/ttyACM* 2>/dev/null
echo ""

# Official UNOs usually appear as ttyACM*, while CH340 clones appear as ttyUSB*
read -p "Enter the port from above (e.g., /dev/ttyACM0): " COMPORT

echo ""
echo "Flashing firmware to $COMPORT at 115200 baud..."

# The UNO R3 uses the ATmega328P, 'arduino' programmer type, and 115200 baud
./avrdude -C avrdude.conf -v -p atmega328p -c arduino -P "$COMPORT" -b 115200 -D -U flash:w:arduino_uno_spar_regular.hex:i

if [ $? -eq 0 ]; then
    echo "========================================="
    echo "SUCCESS: SPAR Firmware updated!"
    echo "========================================="
else
    echo "==================================================================="
    echo "ERROR: Upload failed."
    echo "Make sure the correct port is selected, the UNO is plugged in, "
    echo "and no other programs (like the Arduino IDE IDE/Serial Monitor) "
    echo "are currently using the port."
    echo "==================================================================="
fi
