#!/bin/bash

# Set the exact name of your binary file here
BIN_FILE="arduino_uno_r4_wifi.bin"
FQBN="arduino:renesas_uno:unor4wifi"

echo "==============================================="
echo "  SPAR Arduino UNO R4 WiFi Firmware Flasher"
echo "==============================================="
echo ""

# Check if the binary file exists
if [ ! -f "$BIN_FILE" ]; then
    echo "ERROR: Could not find $BIN_FILE in this folder."
    read -p "Press Enter to exit..."
    exit 1
fi

# Check if arduino-cli exists
if [ ! -f "./arduino-cli" ]; then
    echo "ERROR: arduino-cli not found in this folder."
    read -p "Press Enter to exit..."
    exit 1
fi

# Make sure arduino-cli has execution permissions
chmod +x ./arduino-cli

echo "Setting up board drivers (this takes a moment if running for the first time)..."
./arduino-cli core install arduino:renesas_uno >/dev/null 2>&1

echo "Scanning for connected Arduino UNO R4 WiFi..."
# Find the port by filtering the board list and extracting the first column (e.g., /dev/ttyACM0)
COMPORT=$(./arduino-cli board list | grep "$FQBN" | awk '{print $1}')

if [ -z "$COMPORT" ]; then
    echo ""
    echo "ERROR: Could not find the Arduino UNO R4 WiFi."
    echo "Please ensure it is plugged in via USB and try again."
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "Found board on $COMPORT."
echo ""
echo "Uploading firmware..."
./arduino-cli upload -b "$FQBN" -p "$COMPORT" -i "$BIN_FILE"

if [ $? -ne 0 ]; then
    echo ""
    echo "[X] UPLOAD FAILED."
    echo "--------------------------------------------------------"
    echo "TROUBLESHOOTING: If you got a 'Permission denied' error,"
    echo "your Linux user likely doesn't have Serial port access."
    echo "Run this command in your terminal, then log out and log back in:"
    echo "sudo usermod -a -G dialout \$USER"
    echo "--------------------------------------------------------"
else
    echo ""
    echo "[~] UPLOAD SUCCESSFUL! You can now close this window."
fi

echo ""
read -p "Press Enter to exit..."
