@echo off
setlocal

:: Set the exact name of your binary file here
set "BIN_FILE=arduino_uno_r4_wifi.bin"
set "FQBN=arduino:renesas_uno:unor4wifi"

echo =============================================
echo   SPAR Arduino UNO R4 WiFi Firmware Flasher
echo =============================================
echo.

:: Check if the binary file exists
if not exist "%BIN_FILE%" (
    echo ERROR: Could not find %BIN_FILE% in this folder.
    pause
    exit /b 1
)

:: Check if arduino-cli exists
if not exist "arduino-cli.exe" (
    echo ERROR: arduino-cli.exe not found in this folder.
    pause
    exit /b 1
)

:: Ensure the necessary core is installed (downloads silently if missing)
echo Setting up board drivers (this takes a moment if running for the first time)...
arduino-cli core install arduino:renesas_uno >nul 2>&1

:: Find the COM port
echo Scanning for connected Arduino UNO R4 WiFi...
set "COMPORT="
for /f "tokens=1" %%A in ('arduino-cli board list ^| findstr /C:"%FQBN%"') do (
    set "COMPORT=%%A"
)

if "%COMPORT%"=="" (
    echo.
    echo ERROR: Could not find the Arduino UNO R4 WiFi.
    echo Please ensure it is plugged in via USB and try again.
    echo.
    pause
    exit /b 1
)

echo Found board on %COMPORT%.
echo.
echo Uploading firmware...
arduino-cli upload -b %FQBN% -p %COMPORT% -i "%BIN_FILE%"

if %errorlevel% neq 0 (
    echo.
    echo [X] UPLOAD FAILED. Please read the errors above.
) else (
    echo.
    echo [~] UPLOAD SUCCESSFUL! You can now close this window.
)

echo.
pause
